export declare const Extracti18nTask: any;
