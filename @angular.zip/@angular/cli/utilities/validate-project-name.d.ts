export declare function validateProjectName(projectName: string): void;
