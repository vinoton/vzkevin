export declare function overrideOptions(original: any[], overrides: any[]): any;
