import { Component, OnInit } from '@angular/core';
import { WeatherService } from '../services/weather.service';
import { Chart } from 'chart.js';

@Component({
  selector: 'app-piechart',
  templateUrl: './piechart.component.html',
  styleUrls: ['./piechart.component.css']
})
export class PiechartComponent implements OnInit {
  chart = [];

  constructor(private _weather: WeatherService) {}


  ngOnInit() {
    this._weather.dailyForecast()
      .subscribe(res => {
        let temp_max = res['list'].map(res => res.main.temp_max);
        let temp_min = res['list'].map(res => res.main.temp_min);
        let alldates = res['list'].map(res => res.dt);

        let weatherDates = [];
        alldates.forEach((res) => {
          let jsdate = new Date(res * 1000);
          weatherDates.push(jsdate.toLocaleTimeString('en', { year: 'numeric', month: 'short', day: 'numeric'}));
        });

        this.chart = new Chart('canvas2', {
          type: 'pie',
          data: {
            labels: [
              'Red',
              'Orange',
              'Yellow'],
            datasets: [
              {
                data: temp_max,
                borderColor: '#3cba9f',
                backgroundColor: ['#3cba9f', '#ffcc00', '#F00'],
                fill: false
              },
              {
                data: temp_min,
                borderColor: '#ffcc00',
                backgroundColor: '#FFF',
                fill: false
              },
            ]
          },
          options: {
            responsive: true
          }
        });
      });
  }

}
