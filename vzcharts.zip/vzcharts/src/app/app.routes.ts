import { Routes } from '@angular/router';

import { LinechartComponent } from './linechart/linechart.component';
import { BarchartComponent } from './barchart/barchart.component';
import { PiechartComponent } from './piechart/piechart.component';
import { DashboardComponent } from './dashboard/dashboard.component';

export const appRoutes: Routes = [
    {
    path: 'linechart',
    component: LinechartComponent
    },
    {
    path: 'barchart',
    component: BarchartComponent
    },
    {
    path: 'piechart',
    component: PiechartComponent
    },
    {
    path: 'dashboard',
    component: DashboardComponent
    }
];
