import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recipelist',
  templateUrl: './recipelist.component.html',
  styleUrls: ['./recipelist.component.css']
})
export class RecipelistComponent implements OnInit {
  public selectedEmployeeData: any = {
    selectempName: '',
    selectempCity: '',
    selectempSalary: '',
  };
  public recipelist: any = [
    {
      recipename: 'Chicken Briyani',
      recipeprice: '500',
      recipediscription: 'Chicken Biryani Full Plat'
    },
    {
      recipename: 'Mutton Briyani',
      recipeprice: '700',
      recipediscription: 'Mutton Biryani Full Plat'
    },
    {
      recipename: 'Chicken 65',
      recipeprice: '300',
      recipediscription: 'Chicken 65 6 pices'
    }
    ];
    constructor() { }

    ngOnInit() {
    }

    public getRecords(data: any): void {
      this.selectedEmployeeData = data;
      console.log('send record checking ');
    }
  }
