import { Component, OnInit, ViewChild } from '@angular/core';

import { NgForm } from '@angular/forms';
import { UserService } from '../services/user.service';
import { Gender } from '../model/gender';
import { Country } from '../model/country';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  gender: any[];
  country: any[];
  optiongenderSelected: string;
  optioncountrySelected: string;

  registerDetails: any = {
    username: '',
    password: '',
    email: '',
    firstname: '',
    lastname: '',
    gender: '',
    country: ''
  };

  @ViewChild('f') insertRegister: NgForm;

  constructor(private userService: UserService) { }

  ngOnInit() {
     this.gender = Gender;
     this.country = Country;
  }

  selectgenderName() {
    console.log(this.optiongenderSelected);
  }

  selectcountryName() {
    console.log(this.optioncountrySelected);
  }

  onSubmit(f: NgForm) {
     this.registerDetails = {
      username: this.insertRegister.value.username,
      password: this.insertRegister.value.password,
      email: this.insertRegister.value.email,
      firstname: this.insertRegister.value.firstname,
      lastname: this.insertRegister.value.lastname,
      gender: this.insertRegister.value.gender,
      country: this.optioncountrySelected
     };

     // console.log(this.registerDetails);

       this.userService.setRegister(this.registerDetails)
          .subscribe(
              (res) => {
                if (res.status === 201) {
                  // f.resetForm();
                   alert('register successfully');
                } else {
                  alert(res.json().message);
                }
                console.log(res);
              },
              (err) => {
                console.log(err);
                if (err.status === 409) {
                  alert(err.json().message);
                } else {
                  alert('register failed');
                }
              }
          );
  }
}
