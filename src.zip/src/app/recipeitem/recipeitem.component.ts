import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-recipeitem',
  templateUrl: './recipeitem.component.html',
  styleUrls: ['./recipeitem.component.css']
})
export class RecipeitemComponent implements OnInit {
/* @Input() employeeName: string; */
@Input() recipeName: string;
@Input() recipeCity: string;
@Input() recipeSalary: number;

@Output()
sendRecords: EventEmitter<any> = new EventEmitter<any>();

Fname: string;
constructor() {
  this.Fname = 'kauman';
  this.getSeverStatus();
}

  ngOnInit() {
  }

  public empRecordEvent() {
    const selectCollectionEmp: any = {
      selectempName: this.recipeName,
      selectempCity: this.recipeCity,
      selectempSalary: this.recipeSalary
    };
    this.sendRecords.emit(selectCollectionEmp);
  }

  getSeverStatus() {
    return this.Fname = 'raja';
  }

}
