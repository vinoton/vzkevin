
export const Gender: any = [
  { text: 'Male', value : 'M' },
  { text: 'Female', value : 'F' }
];
