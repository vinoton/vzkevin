import { Injectable } from '@angular/core';
import { Headers, Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

@Injectable()
export class UserService {

  isUserLoggedIn: boolean;
  isUsername: string;
  isToken: string;

  constructor(private http: Http) {

  }

  login(logindetail: any[]) {
     const headers = new Headers ({'Content-Type': 'application/json'});
     return this.http.post('http://localhost:2000/user/login' ,
     logindetail, {headers: headers} );
  }

  setRegister(registerDetails: any[]) {
     const headers = new Headers ({'Content-Type': 'application/json'});
     return this.http.post('http://localhost:2000/user/signup' ,
     registerDetails, {headers: headers} );
  }

  updateUser(userDetail: any[], _id: any) {
    const headers = new Headers ({'Content-Type': 'application/json'});
    return this.http.patch('http://localhost:2000/user/update/' + _id ,
    userDetail, {headers: headers} );
  }

  getUser() {
    // console.log(this.isToken);
    // const headers = new Headers ({'Content-Type': 'application/json'});
    // return this.http.post('http://localhost:2000/user', headers);
       return this.http.get('http://localhost:2000/user')
         .map(
            (res: Response) => {
              const data = res.json(); return data; },
            (err) => { console.log(err); }
         );
  }

  deleteUser(_id) {
    console.log(_id);
    return this.http.delete('http://localhost:2000/user/' + _id);
    // .map(
    //    (res: Response) => {
    //      const data = res.json(); return data; },
    //    (err) => { console.log(err); }
    // )
  }


  getUserLoggedIn() {
    return this.isUserLoggedIn === undefined ? false : this.isUserLoggedIn;
  }

  logout() {
      localStorage.setItem('loginstatus', '0');
      this.isUserLoggedIn = false;
      console.log('loginstatus' + localStorage.getItem('loginstatus'));
      console.log('isUserLoggedIn' + localStorage.getItem('loginstatus'));
      this.isToken = '';
  }
}
