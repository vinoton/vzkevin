import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';


import { AppComponent } from './app.component';
import { RecipelistComponent } from './recipelist/recipelist.component';
import { RecipeitemComponent } from './recipeitem/recipeitem.component';


@NgModule({
  declarations: [
    AppComponent,
    RecipelistComponent,
    RecipeitemComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
