import { Component, OnInit, ViewChild } from '@angular/core';

import { NgForm } from '@angular/forms';
import { UserService } from '../services/user.service';
import { Gender } from '../model/gender';
import { Country } from '../model/country';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})

export class SettingsComponent implements OnInit {
  User: any[];
  gender: any[];
  country: any[];
  optiongenderSelected: any;
  optioncountrySelected: any;
  username: '';
  password: '';
  email: '';
  firstname: '';
  lastname: '';
  usercount: '';
  _id: '';

  userDetails: any = {
    username: '',
    password: '',
    email: '',
    firstname: '',
    lastname: '',
    gender: '',
    country: ''
  };

  @ViewChild('f') updateUser: NgForm;


  constructor(private userService:  UserService) { }

  ngOnInit() {
    this.gender = Gender;
    this.country = Country;

    this.getUser();
  }

  userEdit(user) {
    console.log(user);
    this.username = user.username;
    this.password = user.password;
    this.email = user.email;
    this.firstname = user.firstname;
    this.lastname = user.lastname;
    this.optiongenderSelected = user.gender;
    this.optioncountrySelected = user.country;
    this._id = user._id;
    console.log(this.optiongenderSelected);
    console.log(this.optioncountrySelected);
  }

  onSubmit(f: NgForm) {
     this.userDetails = {
      username: this.updateUser.value.username,
      password: this.updateUser.value.password,
      email: this.updateUser.value.email,
      firstname: this.updateUser.value.firstname,
      lastname: this.updateUser.value.lastname,
      gender: this.optiongenderSelected,
      country: this.optioncountrySelected
     };

     // console.log(this.registerDetails);

     this.userService.updateUser(this.userDetails, this._id)
          .subscribe(
              (res) => {
                if (res.status === 200) {
                  this.username = this.password = this.email = this.firstname = '';
                  this.lastname = this.optiongenderSelected = this.optioncountrySelected = this._id = '';
                  this.getUser();
                   alert('update successfully');
                }
                console.log(res);
              },
              (err) => console.log(err)
          );
  }

  userRemove(_id) {
    console.log(_id);
    this.userService.deleteUser(_id)
          .subscribe(
            (res) => { // this.User = res.user;
              console.log(res);
              this.getUser();
            },
            (err) => { console.log(err); }
          );
  }

  getUser() {
    this.userService.getUser()
          .subscribe(
            (res) => {
              this.usercount = res.count;
              this.User = res.user;
              // console.log(res.user);
            },
            (err) => { console.log(err); }
          );
  }
}
