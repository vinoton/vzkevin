import { Component, OnInit, ViewChild } from '@angular/core';

import { NgForm } from '@angular/forms';
import { UserService } from '../services/user.service';

import { Router } from '@angular/router';
import { HeaderComponent } from '../header/header.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginDetails: any = {
    username: '',
    password: ''
  };

  @ViewChild('f') insertRegister: NgForm;

  constructor(private userService: UserService,
              private router: Router) { }

  ngOnInit() {
  }

  onSubmit(f: NgForm) {
     this.loginDetails = {
      username: this.insertRegister.value.username,
      password: this.insertRegister.value.password
     };

     this.userService.login(this.loginDetails)
          .subscribe(
              (res) => {
                 if (res.status === 200) {
                    this.userService.isUserLoggedIn = true;
                    localStorage.setItem('loginstatus', '1');
                    this.userService.isToken = res.json().token;
                    this.router.navigate(['']);
                  //  console.log(res.json());
                 }
                // console.log(res);
              },
              (err) => {console.log(err);
              alert('login field');
            }
          );

  }
}
