/*
console.log("Welcome to node learning");

const fs = require('fs');

const _ = require('lodash');
const notes = require('./notes.js');

console.log('app Start');

setTimeout(() => {
console.log('Data process take 2 sec');
},2000);

setTimeout(() => {
    console.log('Data process take 0 sec');
    },0);

console.log('End App Process');
*/
const express = require('express');
const app = express();

app.use(express.static('public'));
app.set('view engine', 'ejs');

app.get('/', (req,res) => {
    res.render('home');
});

app.get('/', (req,res) => {
    res.send('Welcome');
});
app.get('/about', (req,res) => {
    res.send('About Page');
});

app.listen(3000);