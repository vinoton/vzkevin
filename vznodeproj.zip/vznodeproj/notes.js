console.log("notes file exceuted");
module.exports.age = 28;

module.exports.addNote = () => {
    console.log("add not calling");
    return "New function value return";
}

module.exports.sum = (a,b) => {
    var tot = a + b;
    return tot;
}

