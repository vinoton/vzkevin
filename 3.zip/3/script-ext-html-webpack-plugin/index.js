'use strict';

const ScriptExtHtmlWebpackPlugin = require('./lib/plugin.js');

module.exports = ScriptExtHtmlWebpackPlugin;
