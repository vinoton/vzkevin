var quote = require('../').quote;
var s = quote([ 'a', 'b c d', '$f', '"g"' ]);
console.log(s);
