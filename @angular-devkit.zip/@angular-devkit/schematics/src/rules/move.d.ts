import { FileOperator, Rule } from '../engine/interface';
export declare function moveOp(from: string, to?: string): FileOperator;
export declare function move(from: string, to?: string): Rule;
