# Angular 2 HMR Loader
Angular 2 HMR Webpack Loader by @AngularClass
Please consider using [AngularClass/angular2-hmr](https://github.com/AngularClass/angular2-hmr) which provides helpers for HMR in Angular 2
```es6
        {
          test: /\.ts$/,
          loaders: [
            '@angularclass/hmr-loader',
            'awesome-typescript-loader'
          ]
        },
```
