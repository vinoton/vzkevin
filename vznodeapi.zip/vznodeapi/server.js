const http = require('http');
const app = require('./app');
const express = require('express');

const port = process.env.PORT || '2000';

const server = http.createServer(app);

server.listen(port);