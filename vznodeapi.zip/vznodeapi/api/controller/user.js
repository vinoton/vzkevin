const mongoose = require('mongoose');
const User = require('../models/user'); 
const jwt = require('jsonwebtoken');

module.exports.USER_GET_LIST = (req, res, next) =>{    
    User.find()
        .select('username email password firstname lastname gender country')
        .exec()
        .then(result=>{
            res.status(200).json({
                count : result.length,
                user: result.map(doc=>{
                    return {
                        _id : doc._id,
                        username : doc.username,
                        email : doc.email,
                        password : doc.password,
                        firstname : doc.firstname,
                        lastname : doc.lastname,
                        gender : doc.gender,
                        country : doc.country,                        
                        request : {
                            type: "GET",
                            url: "http://localhost:2000/user/" + doc._id
                        }
                    }
                })
            });
        })
        .catch(err=>{
            console.log(err);
            res.status(500).json({
                error : err
            });
        });
};

module.exports.USER_LOGIN = (req, res, next) =>{    
    User.find({ username: req.body.username })
        .exec()
        .then(user=>{
            console.log(user);
           if (user.length >= 1)
           { 
                if (user[0].password === req.body.password)
                {
                    const token = jwt.sign({
                        username: user[0].username,
                        userid: user[0]._id
                    }, process.env.JWTKEY, 
                    {
                        expiresIn: "3h"
                    });       
                    res.status(200).json({
                        message : 'Login Successfully',
                        token : token
                    });
                }
          }  
          else 
          {
                return res.status(401).json({
                    message : 'Authendication failed'
                });
           }
        })
        .catch(err=>{
            console.log(err);
            res.status(500).json({
                 error : err
            });
        })
 };
 
 module.exports.USER_UPDATE = (req, res, next) =>{ 
    console.log(req.body);
    console.log(req.params.id);
    User.findByIdAndUpdate(         
            req.params.id,
            req.body,
        )
        .exec()
        .then(user=>{        
           console.log(user);           
           return res.status(200).json({
                   message : 'user name updated successfully'
           })
        })
 };

module.exports.USER_SIGN_UP = (req, res, next) =>{ 
    User.find({ username: req.body.username })
        .exec()
        .then(user=>{
           if (user.length >= 1)
           {
               return res.status(409).json({
                   message : 'user name already exists'
               })
           }
           else 
           {
             const user = new User({
                 _id: new mongoose.Types.ObjectId(),
                 username: req.body.username,
                 email: req.body.email,
                 password: req.body.password,
                 firstname: req.body.firstname,
                 lastname: req.body.lastname,
                 gender: req.body.gender,
                 country: req.body.country
             });
             user
               .save()
               .then(result =>{
                  console.log(result);            
                  res.status(201).json({
                      message : 'signup',
                      userdata : result
                  });
               })
               .catch(err=>{
                   console.log(err);
                   res.status(500).json({
                        error : err
                   });
               })
           }
        })
 };

 module.exports.SINGLE_USER_GET = (req, res, next) =>{    
    User.findById(req.params.id)
        .select('username email password firstname lastname gender country')
        .exec()
        .then(result=>{
            console.log(result);
            res.status(200).json({                
                user: result                
            });
        })
        .catch(err=>{
            console.log(err);
            res.status(500).json({
                error : err
            });
        });
};

module.exports.REMOVE_USER = (req, res, next) =>{    
    User.findByIdAndRemove(req.params.id)        
        .exec()
        .then(result=>{
            console.log(result);
            res.status(200).json({
                message : 'user deleted',
                user: result                
            });
        })
        .catch(err=>{
            console.log(err);
            res.status(500).json({
                error : err
            });
        });
};