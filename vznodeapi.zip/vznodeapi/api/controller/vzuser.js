const mongoose = require('mongoose');
const Vzuser = require('../models/vzuser');
const jwt = require('jsonwebtoken');

module.exports.USER_VZGET_LIST = (req, res, next) =>{    
    Vzuser.find()
        .select('vzusername vzemail vzpassword vzfirstname vzlastname vzgender vzcountry')
        .exec()
        .then(result=>{
            res.status(200).json({
                count : result.length,
                user: result.map(doc=>{
                    return {
                        _id : doc._id,
                        vzusername : doc.vzusername,
                        vzemail : doc.vzemail,
                        vzpassword : doc.vzpassword,
                        vzfirstname : doc.vzfirstname,
                        vzlastname : doc.vzlastname,
                        vzgender : doc.vzgender,
                        vzcountry : doc.vzcountry,                        
                        request : {
                            type: "GET",
                            url: "http://localhost:2000/user/" + doc._id
                        }
                    }
                })
            });
        })
        .catch(err=>{
            console.log(err);
            res.status(500).json({
                error : err
            });
        });
};


module.exports.USER_VZSIGN_UP = (req, res, next) =>{ 
    Vzuser.find({ vzusername: req.body.vzusername })
        .exec()
        .then(user=>{
           if (user.length >= 1)
           {
               return res.status(409).json({
                   message : 'user name already exists'
               })
           }
           else 
           {
             const user = new Vzuser({
                _id: new mongoose.Types.ObjectId(),
                vzusername: req.body.vzusername,
                vzemail: req.body.vzemail,
                vzpassword: req.body.vzpassword,
                vzfirstname: req.body.vzfirstname,
                vzlastname: req.body.vzlastname,
                vzgender: req.body.vzgender,
                vzcountry: req.body.vzcountry
             });
             user
               .save()
               .then(result =>{
                  console.log(result);            
                  res.status(201).json({
                      message : 'vzsignup',
                      userdata : result
                  });
               })
               .catch(err=>{
                   console.log(err);
                   res.status(500).json({
                        error : err
                   });
               })
           }
        })
 };