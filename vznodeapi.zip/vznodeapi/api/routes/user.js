const express = require("express");
const router = express.Router();

const checkAuth = require('../middleware/check-auth');

const UserController = require('../controller/user');
const VzuserController = require('../controller/vzuser');

//router.post('/', checkAuth,  UserController.USER_GET_LIST);
router.get('/', UserController.USER_GET_LIST);

router.post('/signup', UserController.USER_SIGN_UP);

router.get('/vzgetdetails', VzuserController.USER_VZGET_LIST);

router.post('/vzsignup', VzuserController.USER_VZSIGN_UP);

router.post('/login', UserController.USER_LOGIN);

router.patch('/update/:id', UserController.USER_UPDATE);

router.get('/:id', UserController.SINGLE_USER_GET);

router.delete('/:id', UserController.REMOVE_USER);

module.exports = router;