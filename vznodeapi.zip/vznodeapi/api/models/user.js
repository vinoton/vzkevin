const mongoose = require('mongoose');

const userSchma = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    username : { type: String, require: true },
    password: { type: String, require: true },
    email: { 
        type: String, 
        require: true,         
        match: /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/
    },
    firstname: { type: String, require: true },
    lastname: { type: String, require: true },
    gender: { type: String, require: true },
    country: { type: String, require: true }
});

module.exports = mongoose.model('User', userSchma);