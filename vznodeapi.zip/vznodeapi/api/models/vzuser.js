const mongoose = require('mongoose');

const userSchma = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    vzusername : { type: String, require: true },
    vzpassword: { type: String, require: true },
    vzemail: { 
        type: String, 
        require: true,         
        match: /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/
    },
    vzfirstname: { type: String, require: true },
    vzlastname: { type: String, require: true },
    vzgender: { type: String, require: true },
    vzcountry: { type: String, require: true }
});

module.exports = mongoose.model('Vzuser', userSchma);