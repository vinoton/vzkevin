# Angular 5 Charts Tutorial Repo

Clone this repo and run `npm install` in the project folder.
Then run `ng serve` 

This project is based on the [Angular 5 with Chart.js Tutorial](https://coursetro.com/posts/code/126/Let's-build-an-Angular-5-Chart.js-App---Tutorial) from Gary Simon of Coursetro.

Visit [Coursetro Full Stack Tutorials &amp; Courses](https://coursetro.com) for more awesome content.
Also, subscribe to the [Coursetro Youtube Channel](http://youtube.com/user/designcourse) for more.
